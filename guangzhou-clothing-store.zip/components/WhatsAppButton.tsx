export default function WhatsAppButton() {
  return (
    <a className="whatsapp" href="https://wa.me/861234567890">
      WhatsApp Order
    </a>
  )
}