export default function Navbar() {
  return (
    <nav className="nav">
      <a href="/">LOGO</a>
      <div>
        <a href="/catalog">Catalog</a>
        <a href="/contact">Contact</a>
        <a href="/login">Wholesale</a>
      </div>
    </nav>
  )
}