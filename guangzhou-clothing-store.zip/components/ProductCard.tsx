import { Product } from '@/lib/products';

export default function ProductCard({ product }: { product: Product }) {
  return (
    <div className="card">
      <img src="/images/placeholder.jpg" />
      <h3>{product.name}</h3>
      <p>${product.price}</p>
      <a href={`/product/${product.id}`}>View</a>
    </div>
  )
}