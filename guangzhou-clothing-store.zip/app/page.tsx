export default function Home() {
  return (
    <main className="hero">
      <h1>Wholesale & Retail Clothing from Guangzhou</h1>
      <p>Premium fashion for global buyers</p>
      <div>
        <a href="/catalog" className="btn">Shop Now</a>
        <a href="/catalog" className="btn outline">View Catalog</a>
      </div>
    </main>
  )
}