export default function Contact() {
  return (
    <div className="page">
      <h2>Contact Us</h2>
      <p>WhatsApp: +86-XXX-XXXX</p>
      <p>Email: sales@yourbrand.com</p>
    </div>
  )
}