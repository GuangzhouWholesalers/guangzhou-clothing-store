export default function Admin() {
  return (
    <div className="page">
      <h2>Admin Dashboard</h2>
      <input placeholder="Product Name" />
      <input placeholder="Price" />
      <button className="btn">Save</button>
    </div>
  )
}