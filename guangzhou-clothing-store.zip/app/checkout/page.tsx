'use client'
import { useState } from 'react'

export default function Checkout() {
  const [total, setTotal] = useState(100)

  function calc(rate: number) {
    setTotal(100 + 100 * rate)
  }

  return (
    <div className="checkout">
      <h2>Checkout</h2>

      <input placeholder="Full Name" />
      <input placeholder="Shipping Address" />

      <select onChange={e => calc(Number(e.target.value))}>
        <option value="0.05">USA (5%)</option>
        <option value="0.1">EU (10%)</option>
        <option value="0">China (0%)</option>
      </select>

      <h3>Payment</h3>
      <label><input type="radio" /> Credit / Debit Card</label>
      <label><input type="radio" /> Binance Pay</label>

      <input placeholder="Binance ID" />

      <p><strong>Total: ${total.toFixed(2)}</strong></p>

      <button className="btn">Place Order</button>
    </div>
  )
}