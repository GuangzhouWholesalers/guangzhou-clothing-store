export default function Login() {
  return (
    <div className="page">
      <h2>Wholesale Login</h2>
      <input placeholder="Email" />
      <input type="password" placeholder="Password" />
      <button className="btn">Login</button>
    </div>
  )
}