import { products } from '@/lib/products'
import ProductCard from '@/components/ProductCard'

export default function Catalog() {
  return (
    <section className="grid">
      {products.map(p => (
        <ProductCard key={p.id} product={p} />
      ))}
    </section>
  )
}