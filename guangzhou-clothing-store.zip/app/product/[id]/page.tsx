import { products } from '@/lib/products'

export default function Product({ params }: any) {
  const product = products.find(p => p.id == params.id)

  return (
    <div className="product">
      <img src="/images/placeholder.jpg" />
      <h2>{product?.name}</h2>
      <p>${product?.price}</p>

      <select>
        <option>S</option>
        <option>M</option>
        <option>L</option>
        <option>XL</option>
      </select>

      <button className="btn">Add to Cart</button>
    </div>
  )
}