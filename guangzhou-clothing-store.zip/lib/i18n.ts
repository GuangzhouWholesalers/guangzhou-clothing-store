// Placeholder i18n file
export const i18n = {};