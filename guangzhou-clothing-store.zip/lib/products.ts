export interface Product {
  id: number;
  name: string;
  price: number;
}
export const products: Product[] = [
  { id: 1, name: 'Luxury T-Shirt', price: 25 },
  { id: 2, name: 'Premium Hoodie', price: 45 }
];